<?php
include 'conn.php';

$itemcode=$_POST['itemcode'];
$itemname=$_POST['itemname'];
$price=$_POST['price'];
$quality=$_POST['quality'];

$connect->query("INSERT INTO tb_item (item_code,item_name,price,quality) VALUES ('".$itemcode."','".$itemname."','".$price."','".$quality."')")

?>
