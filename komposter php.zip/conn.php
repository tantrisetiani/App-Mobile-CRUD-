<?php

$connect = new mysqli("localhost","root","","komposter");

if($connect) {
	
}else{
	echo "Connection Failed";
	exit();
}